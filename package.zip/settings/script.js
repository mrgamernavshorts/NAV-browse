const backb = document.getElementById('backb')
function closewin(){
    window.close();
}
backb.onclick = closewin;